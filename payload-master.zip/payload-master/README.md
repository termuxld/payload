# payload-generator

membuat paylaod di aplikasi termux

kode perintah 
pkg install bash
cd payload
bash payload.sh


selengkapnya cek di
https://www.kumpulanremaja.com/2019/11/cara-membuat-payload-dengan-termux.html
